import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {

        BankAccount bankAccount1 = new BankAccount("John",1,1000);
        BankAccount bankAccount2 = new BankAccount("David",2,1200);
        BankAccount bankAccount3 = new BankAccount("Micheal",3,1500);
        BankAccount bankAccount4 = new BankAccount("Thomas",4,2000);
        BankAccount bankAccount5 = new BankAccount("Jonny",5,3000);

        ArrayList <BankAccount> bankAccounts = new ArrayList<>();

        bankAccounts.add(bankAccount1);
        bankAccounts.add(bankAccount2);
        bankAccounts.add(bankAccount3);
        bankAccounts.add(bankAccount4);
        bankAccounts.add(bankAccount5);

        System.out.println(bankAccounts);

        Collections.sort(bankAccounts);
        System.out.println(bankAccounts);

        Comparator <BankAccount> balanceComparator = new Comparator<BankAccount>() {
            @Override
            public int compare(BankAccount o1, BankAccount o2) {
                return (int)(o2.getBalance()-o1.getBalance());
            }
        };

        bankAccounts.sort(balanceComparator);
        System.out.println(bankAccounts);
    }
}