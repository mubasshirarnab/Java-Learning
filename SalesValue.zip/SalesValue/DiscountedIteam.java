package SalesValue;

public class DiscountedIteam extends Iteam{
    double discount;

    public DiscountedIteam(String name,double price, double discount){
        this.name = name;
        this.price = price;
        this.discount = discount;
    }

    @Override
    public double getPrice(){
        double dis = (price * discount) / 100;
        return price - dis;
    }
}
