package SalesValue;

public class Iteam {
    String name;
    double price;

    public double getPrice(){
        return price;
    }
}
