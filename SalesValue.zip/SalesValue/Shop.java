package SalesValue;

public class Shop {
    public static void main(String[] args) {
        Iteam[] iteams = new Iteam[5];

        iteams[0] = new DiscountedIteam("Car", 10000,15);
        iteams[1] = new DiscountedIteam("T-Shirt", 1000,5);
        iteams[2] = new DiscountedIteam("Watch", 2500,7);
        iteams[3] = new DiscountedIteam("Mobile", 33000,10);
        iteams[4] = new DiscountedIteam("Shoes", 2300,12);

        double sum = 0;
        for (int i = 0; i < iteams.length; i++){
            System.out.println("Price after Discount: " + iteams[i].getPrice());
            sum += iteams[i].getPrice();
        }
        System.out.println("The total sales value: " + sum);
    }
}
