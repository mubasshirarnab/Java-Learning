import java.util.ArrayList;
import java.util.Scanner;

public class AddressBook {
    ArrayList <Info> contacts = new ArrayList<>();
    Scanner sc = new Scanner(System.in);

    public void addRecord(){
        String name = sc.nextLine();
        String contactNumber = sc.nextLine();
        String emailAddress = sc.nextLine();
        contacts.add(new Info(name, contactNumber, emailAddress));
    }

    public void updateRecord(String name){
        for (Info c: contacts){
            if (c.getName().equals(name)){
                System.out.println("Record found successfully. Enter the updated Information.");
                String newName = sc.nextLine();
                String newContactNumber = sc.nextLine();
                String newEmailAddress = sc.nextLine();

                c.setName(newName);
                c.setContactNumber(newContactNumber);
                c.setEmailAccount(newEmailAddress);
            }
        }
    }

    public void deleteRecord(String name){
        for (int i = 0; i < contacts.size(); i++){
            if (contacts.get(i).getName().equals(name)){
                contacts.remove(contacts.get(i));
                System.out.println("Record deleted successfully");
            }
        }
    }
    public void printDetails(){
        for (Info c: contacts){
            System.out.println(c);
        }
    }
}
