public class Main {
    public static void main(String[] args) {
        AddressBook addressBook = new AddressBook();

        addressBook.addRecord();
        addressBook.addRecord();

        addressBook.printDetails();

        addressBook.updateRecord("Alisha");
        addressBook.printDetails();

        addressBook.deleteRecord("Arnab");
        addressBook.printDetails();
    }
}