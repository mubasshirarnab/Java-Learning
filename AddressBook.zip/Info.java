public class Info {
    private String name;
    private String contactNumber;
    private String emailAccount;

    public Info(String name, String contactNumber, String emailAccount) {
        this.name = name;
        this.contactNumber = contactNumber;
        this.emailAccount = emailAccount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmailAccount() {
        return emailAccount;
    }

    public void setEmailAccount(String emailAccount) {
        this.emailAccount = emailAccount;
    }

    @Override
    public String toString() {
        return "Name : '" + name + '\'' +
                ", ContactNumber : '" + contactNumber + '\'' +
                ", EmailAccount : '" + emailAccount + '\'';
    }

    public void printDetails(){
        System.out.println("Name: " + name);
        System.out.println("Contact Number: " + contactNumber);
        System.out.println("Email Address: " + emailAccount);
    }
}
