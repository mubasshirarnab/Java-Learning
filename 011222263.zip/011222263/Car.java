public class Car extends Automobile{

	Car(String type) {
		super(type);
		// initialize fuel.
		fuel = 30;
	}
	
	public Car() {
		
	}
	
	void setType(String type){
		super.type = type;
	}
	
	@Override
	void TurnLeft() {
		direction.rotateDirection(5);
		System.out.println("Successfully turn 5 degree in left");
	}
	
	@Override
	void TurnRight() {
		direction.rotateDirection(-5);
		System.out.println("Successfully turn 5 degree in right");
	}
	
	@Override
	void IncreaseSpeed() {
		if(speed < 120){
			speed +=10;
			System.out.println("Speed increased by 10 units");
		}
		else {
			System.out.println("Maximum speed level reached. Please decrease speed");
		}
	}
	
	@Override
	void DecreaseSpeed() {
		if(speed > 0){
			speed -= 10;
			System.out.println("Speed decreased by 10 units");
		}
		else {
			System.out.println("Minimum speed level reached. Please increase the speed");
		}
	}
	
	@Override
	void Move() {
		double amount;

		if(fuel < 0){
			System.out.println("Not enough fuel. Fill fuel first");
		}
		else {
			amount = speed * (1.0 / 3600.0);    // 1 hour = 3600
			position.x = position.x + direction.x * amount;
			position.y = position.y + direction.y * amount;
			fuel = fuel - amount * 8;
			totalDistance += amount;

			System.out.println("The Car moved successfully");
			System.out.println("Total distance moved: " + totalDistance);
			System.out.println("Remaining Fuel after move: " + fuel);
		}

	}

}
