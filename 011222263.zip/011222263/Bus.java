public class Bus extends AutomobileWithManualXmission {
    Bus(String type) {
        super(type);
        // initialize fuel
        fuel = 80;
    }

    @Override
    void TurnLeft() {
        direction.rotateDirection(15);
        System.out.println("Successfully turned 15 degree in left");
    }

    @Override
    void TurnRight() {
        direction.rotateDirection(-15);
        System.out.println("Successfully turned 15 degree in right");
    }

    @Override
    void IncreaseSpeed() {
        // you can not increase your speed beyond current gear position's high limit.
        //if(speed + amount > currentHighLimit) error
        switch (gearPosition) {
            case 0:
                speed = 0;
                System.out.println("Shift the Gear Up");
                break;
            case 1:
                speed += 6;
                if (speed <= 20) {
                    System.out.println("Speed increased 6 unites");
                } else {
                    System.out.println("Maximum level of speed reached. You need to increase the Gear.");
                    speed = 20;
                }
                break;

            case 2:
                speed += 6;
                if (speed <= 30) {
                    System.out.println("Speed increased 6 units");
                } else {
                    System.out.println("Maximum level of speed reached. You need to increase the Gear.");
                    speed = 30;
                }
                break;

            case 3:
                speed += 6;
                if (speed <= 45) {
                    System.out.println("Speed increased 6 units");
                } else {
                    System.out.println("Maximum level of speed reached. You need to increase the Gear.");
                    speed = 45;
                }
                break;

            case 4:
                speed += 6;
                if (speed <= 50) {
                    System.out.println("Speed increased 6 units");
                } else {
                    System.out.println("Maximum level of speed reached. You need to increase the Gear.");
                    speed = 50;
                }
                break;

            case 5:
                speed += 6;
                if (speed <= 60) {
                    System.out.println("Speed increased 6 units");
                } else {
                    System.out.println("Maximum level of speed reached. You need to decrease the Gear.");
                    speed = 60;
                }
                break;

            default:
                System.out.println("The Bus is off");
                break;
        }
    }

    @Override
    void DecreaseSpeed() {
        // you can not decrease your speed below current gear position's low limit.
        //if(speed - amount < currentLowLimit) error
        switch (gearPosition) {
            case 0:
                speed = 0;
                System.out.println("You need to increase the Gear");
                break;

            case 1:
                speed -= 6;
                if (speed < 0) {
                    System.out.println("You need to decrease the Gear");
                    speed = 0;
                } else System.out.println("Speed decreased 6 unites");
                break;

            case 2:
                speed -= 6;
                if (speed < 10) {
                    System.out.println("You need to decrease the Gear");
                    speed = 10;
                } else System.out.println("Speed decreased 6 unites");
                break;
            case 3:
                speed -= 6;
                if (speed < 25) {
                    System.out.println("You need to decrease the Gear");
                    speed = 25;
                } else System.out.println("Speed decreased 6 unites");
                break;

            case 4:
                speed -= 6;
                if (speed < 35) {
                    System.out.println("You need to decrease the Gear");
                    speed = 35;
                } else System.out.println("Speed decreased 6 unites");
                break;

            case 5:
                speed -= 6;
                if (speed < 50) {
                    System.out.println("You need to decrease the Gear");
                    speed = 50;
                } else System.out.println("Speed decreased 6 unites");
                break;
            default:
                System.out.println("The Bus is off");
                break;
        }
    }

    @Override
    void Move() {
        double amount;
        if(fuel > 0){
            if(gearPosition > 0){
                amount = speed * (1.0 / 3600.0);  // 1 hour = 3600
                position.x = position.x + direction.x * amount;
                position.y = position.y + direction.y * amount;
                fuel = fuel - amount * 4;
                totalDistance += amount;

                System.out.println("The Bus Moved Successfully");
                System.out.println("Total distance moved: " + totalDistance);
                System.out.println("Remaining Fuel after move: " + fuel);
            }
            else System.out.println("You need to increase your gear first.");
        }
        else System.out.println("Not enough fuel. Fill fuel first");
    }

}
