
public class AutomobileTest {
	public static void main(String[] args) {
		Car car = new Car("Automatic");
		car.SetInitialPosition(new Coordinate(10,30));
		car.SetInitialDirection(new Coordinate(10,30));
		car.TurnLeft();
		car.IncreaseSpeed();
		car.IncreaseSpeed();
		car.IncreaseSpeed();
		car.Move();
		car.Move();
		car.Move();
		car.TurnRight();
		car.IncreaseSpeed();

		System.out.println();
		
		Truck truck = new Truck("Manual");
		truck.SetInitialPosition(new Coordinate(10,30));
		truck.SetInitialDirection(new Coordinate(10,30));
		truck.Move(); // error
		truck.TurnLeft();
		truck.ShiftGearUp();
		truck.IncreaseSpeed();//4
		truck.IncreaseSpeed();//8
		truck.Move();
		truck.TurnRight();
		truck.IncreaseSpeed();//12
		truck.IncreaseSpeed();//16
		truck.Move();
		truck.IncreaseSpeed();//20
		truck.IncreaseSpeed();//24 error.
		truck.ShiftGearUp();
		truck.IncreaseSpeed();
		truck.Move();

		System.out.println();

		Bus bus = new Bus("Manual");
		bus.SetInitialPosition(new Coordinate(10,30));
		bus.SetInitialDirection(new Coordinate(10,30));
		bus.Move();
		bus.IncreaseSpeed();
		bus.ShiftGearUp();
		bus.IncreaseSpeed();
		bus.IncreaseSpeed();
		bus.IncreaseSpeed();
		bus.TurnRight();
		bus.TurnRight();
		bus.TurnLeft();
		bus.Move();
		bus.IncreaseSpeed();

		System.out.println();

		SUV suv = new SUV("Automatic");
		suv.SetInitialPosition(new Coordinate(10,30));
		suv.SetInitialDirection(new Coordinate(10,30));
		suv.TurnLeft();
		suv.IncreaseSpeed();
		suv.Move();
		suv.TurnRight();
		suv.IncreaseSpeed();
		suv.IncreaseSpeed();
		suv.IncreaseSpeed();
		suv.IncreaseSpeed();
		suv.IncreaseSpeed();







	}
}
