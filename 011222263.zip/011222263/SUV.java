public class SUV extends Automobile{
    SUV(String type){
        super(type);
        // initialize fuel.
        fuel = 50;
    }

    @Override
    void TurnLeft(){
        direction.rotateDirection(10);
        System.out.println("Successfully turn 10 degree in left");
    }

    @Override
    void TurnRight(){
        direction.rotateDirection(-10);
        System.out.println("Successfully turn 10 degree in left");
    }

    @Override
    void IncreaseSpeed(){
        if (speed < 100){
            speed += 8;
            System.out.println("Speed increased 8 units");
        }
        else {
            System.out.println("Maximum level of speed reached. Please decrease the speed.");
        }
    }

    @Override
    void DecreaseSpeed(){
        if (speed > 0){
            speed -= 8;
            System.out.println("Speed decreased by 8 units");
        }
        else {
            System.out.println("Minimum speed level reached. Please increase the speed");
        }
    }

    @Override
    void Move(){
        double amount;

        if(fuel < 0){
            System.out.println("Not enough fuel. Fill fuel first");
        }
        else {
            amount = speed * (1.0 / 3600.0);    // 1 hour = 3600
            position.x = position.x + direction.x * amount;
            position.y = position.y + direction.y * amount;
            fuel = fuel - amount * 6;
            totalDistance += amount;

            System.out.println("The SUV moved successfully");
            System.out.println("Total distance moved: " + totalDistance);
            System.out.println("Remaining Fuel after move: " + fuel);
        }
    }
}
